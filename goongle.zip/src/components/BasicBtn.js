import "./BasicBtn.css";

const BasicBtn = ()=>{}

export default BasicBtn;